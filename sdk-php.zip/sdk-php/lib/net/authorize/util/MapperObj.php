<?php
namespace net\authorize\util;

class MapperObj{

	public $isCustomDefined = false;

	public $className = null;

	public $isArray = false;

	public $isInlineArray = false;

	public $arrayEntryname = null;
}
//echo $classes['net\authorize\api\contract\v1\ANetApiRequestType']['properties']['merchantAuthentication']['type']."\n";

//$value = Yaml::parseFile('/*.yaml');

?>
